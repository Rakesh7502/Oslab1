#include <bits/stdc++.h>
using namespace std;

int main(){
	int len;
	cin>>len;
	vector <int> v;
	for(int i=0;i<len;i++){
		int e;
		cin>>e;
		v.push_back(e);
	}
	int frames;
	cin>>frames;
	vector <int> st;
	queue <int> que;
	int faults=0,hits=0;
	for(int i=0;i<len;i++){
		if(st.size()<frames){
			if(find(st.begin(),st.end(),v[i])==st.end()){
				st.push_back(v[i]);
				faults++;
				que.push(v[i]);
			}
			else{
				hits++;
			}

		}
		else{
			if(find(st.begin(),st.end(),v[i])==st.end()){
				int ele = que.front();
				que.pop();
				for(int j=0;j<frames;j++){
					if(ele == st[j]){
						 st[j]=v[i];
						 break;
					}
					
				}
				que.push(v[i]);
				faults++;
			}
			else{
				hits++;
			}
		}
		for(auto &it:st){
			cout<<it<<" ";
		}
		cout<<endl;
	}
	cout<<"Page Faults: "<<faults<<endl;
	cout<<"Hits: "<<hits<<endl;
	return 0;
}
