#include<bits/stdc++.h>
using namespace std;


 bool isContains(queue<int> q, int x){ 
    while(!q.empty()){ 
        if(q.front() == x) 
            return true; 
            q.pop(); 
            } 
        return false; 
        } 
int pageFaults(int pages[],int n,int capacity){
	queue<int> q;

	int page_faults=0;
	for(int i=0;i<capacity;i++){
		q.push(pages[i]);
		page_faults++;
	}
	for(int i=capacity+1;i<=n;i++){
		if(isContains(q,pages[i])){
			continue;
		}
		else{
			q.pop();
			q.push(pages[i]);
			page_faults++;
		}
	}
	return page_faults;
}



int main(){
	int n,x;
	cout<<"enter no.of pages"<<endl;
	cin>>n;
	int pages[n];
	int capacity;
	cout<<"enter pages"<<endl;
	for(int i=0;i<n;i++){
		cin>>x;
		pages[i]=x;
	}
	
//	int a[]={1,2,3,4,5};
	cout<<"Enter no.of frames"<<endl;
	cin>>capacity; 
   //nt n = sizeof(pages)/sizeof(pages[0]);
    cout <<"Total page faults:"<< pageFaults(pages, n, capacity); 
	
	
	
}
